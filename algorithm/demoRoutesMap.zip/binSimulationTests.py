import pandas as pd
import math

BIN_SIM_PATH = "binSimulation.csv"

REQUIRED_COLUMNS = [
    "bin_id",
    "lat",
    "lon",
    "route_id",
    "service_day",
    "capacity_l",
    "service_time_min",
    "base_growth_l_per_day",
    "noise_l",
    "fill_l_today",
    "predicted_fill_pct",
]


# ---------- TEST 1: File exists & loads ----------
def test_file_exists():
    try:
        pd.read_csv(BIN_SIM_PATH)
        print(f"PASS: {BIN_SIM_PATH} loaded.")
    except Exception as e:
        print(f"FAIL: {BIN_SIM_PATH} missing or unreadable.", e)


# ---------- TEST 2: Columns exist ----------
def test_columns():
    try:
        df = pd.read_csv(BIN_SIM_PATH)
    except Exception as e:
        print("SKIP: Could not load binSimulation.csv for column test:", e)
        return

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        print("FAIL: binSimulation.csv missing columns:", missing)
    else:
        print("PASS: binSimulation.csv has all required columns.")


# ---------- TEST 3: Basic value ranges ----------
def test_basic_value_ranges():
    try:
        df = pd.read_csv(BIN_SIM_PATH)
    except Exception as e:
        print("SKIP: Could not load binSimulation.csv for range checks:", e)
        return

    ok = True

    # lat / lon look like real coordinates
    if df["lat"].between(-90, 90).all() and df["lon"].between(-180, 180).all():
        print("PASS: lat / lon values are in valid ranges.")
    else:
        print("FAIL: Some lat/lon values are out of range.")
        ok = False

    # capacity_l non-negative (and probably > 0)
    if (df["capacity_l"] >= 0).all():
        print("PASS: All capacity_l values are non-negative.")
    else:
        print("FAIL: Some capacity_l values are negative.")
        ok = False

    # service_time_min non-negative
    if (df["service_time_min"] >= 0).all():
        print("PASS: All service_time_min values are non-negative.")
    else:
        print("FAIL: Some service_time_min values are negative.")
        ok = False

    # fill_l_today >= 0 and <= capacity_l
    bad_fill = (df["fill_l_today"] < 0) | (df["fill_l_today"] > df["capacity_l"] + 1e-6)
    if bad_fill.any():
        print("FAIL: Some fill_l_today values are negative or exceed capacity_l.")
        print(df.loc[bad_fill, ["bin_id", "fill_l_today", "capacity_l"]].head())
        ok = False
    else:
        print("PASS: All fill_l_today values are in [0, capacity_l].")

    # predicted_fill_pct in [0, 100]
    if df["predicted_fill_pct"].between(0, 100).all():
        print("PASS: All predicted_fill_pct values are in [0, 100].")
    else:
        print("FAIL: Some predicted_fill_pct values are outside [0, 100].")
        ok = False

    if ok:
        print("PASS: Basic numeric value ranges look good for binSimulation.csv.")


# ---------- TEST 4: Consistency between fill_l_today and predicted_fill_pct ----------
def test_fill_consistency(tol_pct: float = 2.0):
    """
    Check that predicted_fill_pct ≈ (fill_l_today / capacity_l) * 100
    within a tolerance (default 2 percentage points).
    """
    try:
        df = pd.read_csv(BIN_SIM_PATH)
    except Exception as e:
        print("SKIP: Could not load binSimulation.csv for consistency check:", e)
        return

    # avoid division by zero
    nonzero_cap = df["capacity_l"] > 0
    df_nz = df[nonzero_cap].copy()
    if df_nz.empty:
        print("SKIP: No rows with capacity_l > 0 for consistency check.")
        return

    df_nz["computed_pct"] = (df_nz["fill_l_today"] / df_nz["capacity_l"]) * 100.0
    df_nz["abs_error"] = (df_nz["computed_pct"] - df_nz["predicted_fill_pct"]).abs()

    bad = df_nz["abs_error"] > tol_pct
    if bad.any():
        print(
            f"FAIL: Some rows have predicted_fill_pct inconsistent with "
            f"fill_l_today/capacity_l by more than {tol_pct} percentage points."
        )
        print(
            df_nz.loc[
                bad,
                [
                    "bin_id",
                    "fill_l_today",
                    "capacity_l",
                    "predicted_fill_pct",
                    "computed_pct",
                    "abs_error",
                ],
            ].head()
        )
    else:
        print(
            f"PASS: predicted_fill_pct is consistent with fill_l_today/capacity_l "
            f"within {tol_pct} percentage points for all rows."
        )


# ---------- TEST 5: Categorical sanity (service_day, uniqueness) ----------
def test_categorical_sanity():
    try:
        df = pd.read_csv(BIN_SIM_PATH)
    except Exception as e:
        print("SKIP: Could not load binSimulation.csv for categorical checks:", e)
        return

    # service_day values from Mon–Fri
    valid_days = {"Mon", "Tue", "Wed", "Thu", "Fri"}
    if "service_day" in df.columns:
        bad_days = ~df["service_day"].isin(valid_days)
        if bad_days.any():
            print("FAIL: Some service_day values are not in Mon–Fri:")
            print(df.loc[bad_days, ["bin_id", "service_day"]].head())
        else:
            print("PASS: All service_day values are in Mon–Fri.")
    else:
        print("SKIP: No 'service_day' column found for day-of-week checks.")

    # bin_id uniqueness
    if df["bin_id"].is_unique:
        print("PASS: bin_id values are unique.")
    else:
        print("FAIL: Duplicate bin_id values found.")
        dups = df[df["bin_id"].duplicated(keep=False)].sort_values("bin_id")
        print(dups.head())


# =========================================================
#  ADDITIONAL TESTS FOR THE ROUTING ALGORITHM (optimizeRoutes7)
# =========================================================

def test_optimizer_runs_on_binSimulation():
    """
    Basic smoke test: solve_routes() should produce routes
    for at least one truck on binSimulation.csv.
    """
    try:
        from optimizeRoutes7 import solve_routes
    except Exception as e:
        print("SKIP: Could not import optimizeRoutes7 for optimizer test:", e)
        return

    try:
        routes = solve_routes(verbose=False)
    except Exception as e:
        print("FAIL: solve_routes() raised an error:", e)
        return

    if routes and any("truck_id" in r for r in routes):
        print("PASS: Optimizer produced routes for at least one truck.")
    else:
        print("FAIL: Optimizer returned no routes.")


def test_urgent_bins_are_included():
    """
    Pick a few bins and mark them as urgent, then verify each urgent bin
    appears in at least one route.
    """
    try:
        from optimizeRoutes7 import solve_routes, DF_BINS
    except Exception as e:
        print("SKIP: Could not import optimizeRoutes7 for urgent-bin test:", e)
        return

    df = DF_BINS

    if df.empty:
        print("SKIP: DF_BINS is empty; cannot test urgent bins.")
        return

    # Choose up to 3 example bin_ids to treat as urgent
    sample_ids = df["bin_id"].head(3).tolist()
    urgent_bin_ids = sample_ids

    try:
        routes = solve_routes(urgent_bin_ids=urgent_bin_ids, verbose=False)
    except Exception as e:
        print("FAIL: solve_routes() raised an error in urgent-bin test:", e)
        return

    if not routes:
        print("FAIL: No routes returned in urgent-bin test.")
        return

    # Collect all stops across all trucks
    all_stops = set()
    for r in routes:
        all_stops.update(r.get("stops", []))

    missing = [b for b in urgent_bin_ids if b not in all_stops]
    if missing:
        print("FAIL: Some urgent bins are missing from the routes:", missing)
    else:
        print(
            f"PASS: All urgent bins {urgent_bin_ids} appear in at least one route."
        )


def osrm_can_drive(lat1, lon1, lat2, lon2):
    """
    Helper: ask OSRM if there's a driving route between two coordinates.
    If anything goes wrong (no network, OSRM down), we return None so
    the caller can SKIP instead of FAIL.
    """
    import requests

    url = (
        "http://router.project-osrm.org/route/v1/driving/"
        f"{lon1},{lat1};{lon2},{lat2}?overview=false"
    )
    try:
        r = requests.get(url, timeout=5)
        r.raise_for_status()
        data = r.json()
        if "routes" in data and len(data["routes"]) > 0:
            return True
        else:
            return False
    except Exception:
        # Network or OSRM server issue -> caller should SKIP
        return None


def test_route_segments_use_real_roads(num_trucks: int = 3):
    """
    For each A→B leg in each route, check that OSRM can build
    a real-world driving route. If OSRM or the network is unavailable,
    SKIP instead of FAIL.
    """
    try:
        from optimizeRoutes7 import solve_routes, DF_BINS
    except Exception as e:
        print("SKIP: Could not import optimizeRoutes7 for road-network test:", e)
        return

    try:
        routes = solve_routes(num_vehicles=num_trucks, verbose=False)
    except Exception as e:
        print("FAIL: solve_routes() raised an error in road-network test:", e)
        return

    if not routes:
        print("FAIL: No routes returned in road-network test.")
        return

    df = DF_BINS.set_index("bin_id")

    bad_segments = []
    skipped_due_to_osrm = False

    for r in routes:
        stops = r.get("stops", [])
        for a, b in zip(stops[:-1], stops[1:]):
            if a not in df.index or b not in df.index:
                bad_segments.append((a, b, "missing bin_id in DF_BINS"))
                continue

            lat1, lon1 = df.loc[a, ["lat", "lon"]]
            lat2, lon2 = df.loc[b, ["lat", "lon"]]

            can_drive = osrm_can_drive(lat1, lon1, lat2, lon2)
            if can_drive is None:
                # OSRM / network issue: bail out as SKIP
                skipped_due_to_osrm = True
                break
            elif not can_drive:
                bad_segments.append((a, b, "no OSRM driving route"))

        if skipped_due_to_osrm:
            break

    if skipped_due_to_osrm:
        print(
            "SKIP: OSRM or network appears unavailable; "
            "cannot verify road-network segments."
        )
        return

    if bad_segments:
        print("FAIL: Some route legs do not have a valid road path according to OSRM:")
        for a, b, reason in bad_segments[:10]:
            print(f"  {a} -> {b}: {reason}")
    else:
        print("PASS: All route legs have OSRM-supported road paths (real roads).")


# ---------- MAIN ----------
if __name__ == "__main__":
    print("=== Tests for binSimulation.csv ===")
    test_file_exists()
    test_columns()
    test_basic_value_ranges()
    test_fill_consistency()
    test_categorical_sanity()

    print("\n=== Tests for optimizeRoutes7 (routing algorithm) ===")
    test_optimizer_runs_on_binSimulation()
    test_urgent_bins_are_included()
    test_route_segments_use_real_roads(num_trucks=3)
