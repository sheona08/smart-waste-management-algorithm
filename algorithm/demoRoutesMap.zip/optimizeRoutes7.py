import math
from typing import List, Optional, Dict, Any

import pandas as pd
import requests
from ortools.constraint_solver import pywrapcp, routing_enums_pb2


# ---------------------------------------------------------
# CONFIG
# ---------------------------------------------------------

# Default number of vehicles; can be overridden in solve_routes / CLI
DEFAULT_NUM_VEHICLES = 2

# How "full" a bin (0.0–1.0) must be before we *definitely* service it
FILL_THRESHOLD = 0.80

# If nothing reaches the threshold, we fall back to this many bins per vehicle
FALLBACK_TOP_N_PER_VEHICLE = 10

# Vehicle settings
VEHICLE_CAPACITY_L = 8000          # liters per truck
MAX_ROUTE_MIN = 8 * 60             # max route duration per vehicle, in minutes

# Used as fallback if road routing is not used or fails
VEHICLE_SPEED_KMH = 30.0           # average speed to convert distance -> travel time

DEPOT_NAME = "DEPOT_MAIN"

# Road-network routing config
USE_ROAD_NETWORK = True            # set False to go back to pure Haversine
OSRM_MAX_NODES = 100               # safety limit for OSRM table API (demo server)


# ---------------------------------------------------------
# LOAD BIN DATA
# ---------------------------------------------------------

def _load_bins(path: str = "binSimulation.csv") -> pd.DataFrame:
    """Load the bin dataframe and enforce basic types."""
    df = pd.read_csv(path)
    if "bin_id" in df.columns:
        df["bin_id"] = df["bin_id"].astype(int)
    return df


# Load at import time so tests can use it right away
DF_BINS = _load_bins()


# ---------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------

def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two points on Earth (km)."""
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = (
        math.sin(dphi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def _build_matrices_haversine(nodes: pd.DataFrame):
    """Fallback: build matrices using straight-line distance + constant speed."""
    n = len(nodes)
    dist_km = [[0.0] * n for _ in range(n)]
    travel_time_min = [[0] * n for _ in range(n)]
    service_time_min = [0] * n

    for i in range(n):
        lat_i = nodes.loc[i, "lat"]
        lon_i = nodes.loc[i, "lon"]
        for j in range(n):
            if i == j:
                continue
            lat_j = nodes.loc[j, "lat"]
            lon_j = nodes.loc[j, "lon"]

            d_km = haversine_km(lat_i, lon_i, lat_j, lon_j)
            dist_km[i][j] = d_km

            # Convert distance -> travel time (minutes)
            if VEHICLE_SPEED_KMH > 0:
                tt_min = (d_km / VEHICLE_SPEED_KMH) * 60.0
            else:
                tt_min = 0.0
            travel_time_min[i][j] = int(math.ceil(tt_min))

    # Service time at each node (depot has 0)
    if "service_time_min" in nodes.columns:
        for i in range(1, n):  # skip depot at 0
            service_time_min[i] = int(
                max(0, round(float(nodes.loc[i, "service_time_min"])))
            )

    return dist_km, travel_time_min, service_time_min


def _build_matrices_osrm(nodes: pd.DataFrame):
    """
    Try to build distance (km) and travel-time (min) matrices using OSRM road network.

    If anything fails (too many nodes, OSRM error, etc.), fall back to Haversine.
    """
    n = len(nodes)

    # If we choose not to use road network or too many nodes, fall back
    if not USE_ROAD_NETWORK or n > OSRM_MAX_NODES:
        return _build_matrices_haversine(nodes)

    # Build coordinate string for OSRM table API (lon,lat;lon,lat;...)
    coords = ";".join(
        f"{nodes.loc[i, 'lon']},{nodes.loc[i, 'lat']}" for i in range(n)
    )
    url = (
        "http://router.project-osrm.org/table/v1/driving/"
        f"{coords}?annotations=distance,duration"
    )

    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        if "distances" not in data or "durations" not in data:
            return _build_matrices_haversine(nodes)

        distances = data["distances"]   # meters
        durations = data["durations"]   # seconds

        # Initialize matrices
        dist_km = [[0.0] * n for _ in range(n)]
        travel_time_min = [[0] * n for _ in range(n)]
        service_time_min = [0] * n

        # Fill from OSRM
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                d_m = distances[i][j]
                t_s = durations[i][j]
                if d_m is None or t_s is None:
                    # Fall back to Haversine for that pair
                    lat_i = nodes.loc[i, "lat"]
                    lon_i = nodes.loc[i, "lon"]
                    lat_j = nodes.loc[j, "lat"]
                    lon_j = nodes.loc[j, "lon"]
                    d_km = haversine_km(lat_i, lon_i, lat_j, lon_j)
                    if VEHICLE_SPEED_KMH > 0:
                        tt_min = (d_km / VEHICLE_SPEED_KMH) * 60.0
                    else:
                        tt_min = 0.0
                else:
                    d_km = d_m / 1000.0
                    tt_min = t_s / 60.0

                dist_km[i][j] = d_km
                travel_time_min[i][j] = int(math.ceil(tt_min))

        # Service time at each node (depot has 0)
        if "service_time_min" in nodes.columns:
            for i in range(1, n):  # skip depot at 0
                service_time_min[i] = int(
                    max(0, round(float(nodes.loc[i, "service_time_min"])))
                )

        return dist_km, travel_time_min, service_time_min

    except Exception:
        return _build_matrices_haversine(nodes)


def _build_matrices(nodes: pd.DataFrame):
    """
    Wrapper that tries to use OSRM road-network distances/time.
    Falls back to Haversine if needed.
    """
    return _build_matrices_osrm(nodes)


def _select_bins(
    df: pd.DataFrame,
    urgent_bin_ids: Optional[List[int]] = None,
    service_day_filter: Optional[str] = None,
    num_vehicles: int = DEFAULT_NUM_VEHICLES,
) -> pd.DataFrame:
    """Pick which bins to consider in the optimization (before capacity trimming).

    - Optionally filters by service_day.
    - Takes all bins above FILL_THRESHOLD.
    - If none, falls back to top-N fullest bins.
    - Ensures urgent_bin_ids are always included if present in the data.
    """
    data = df.copy()

    # Optional: filter by service day if requested and column exists
    if service_day_filter and "service_day" in data.columns:
        data = data[data["service_day"] == service_day_filter]

    if data.empty:
        return data

    # All bins above threshold
    threshold_pct = FILL_THRESHOLD * 100.0
    selected = data[data["predicted_fill_pct"] >= threshold_pct].copy()

    # Fallback: if nothing above threshold, take the top-N fullest bins overall
    if selected.empty:
        top_n = FALLBACK_TOP_N_PER_VEHICLE * num_vehicles
        selected = (
            data.sort_values("predicted_fill_pct", ascending=False)
            .head(top_n)
            .copy()
        )

    # Ensure urgent bins are always included
    if urgent_bin_ids:
        urgent_mask = data["bin_id"].isin(urgent_bin_ids)
        urgent_rows = data[urgent_mask]
        if not urgent_rows.empty:
            selected = (
                pd.concat([selected, urgent_rows])
                .drop_duplicates(subset="bin_id")
                .reset_index(drop=True)
            )

    return selected


# ---------------------------------------------------------
# MAIN SOLVER
# ---------------------------------------------------------

def solve_routes(
    urgent_bin_ids: Optional[List[int]] = None,
    service_day_filter: Optional[str] = None,
    num_vehicles: int = DEFAULT_NUM_VEHICLES,
    verbose: bool = True,
) -> List[Dict[str, Any]]:
    """Solve the VRP and return a list of route summaries.

    Each element in the returned list looks like:
        {
            "truck_id": 0,
            "stops": [12, 5, 42],
            "total_time_min": 123,
            "total_load_l": 4567
        }
    """
    if num_vehicles <= 0:
        raise ValueError("num_vehicles must be >= 1")

    df = DF_BINS

    # First, choose bins based on fullness, day, and urgency
    selected = _select_bins(df, urgent_bin_ids, service_day_filter, num_vehicles)
    if selected.empty:
        if verbose:
            if service_day_filter:
                print(
                    f"No bins selected for routing "
                    f"(service_day={service_day_filter}, "
                    f"threshold={FILL_THRESHOLD*100:.0f}%)."
                )
            else:
                print(
                    f"No bins selected for routing "
                    f"(threshold={FILL_THRESHOLD*100:.0f}%)."
                )
        return []

    # -------------------------------------------------
    # Capacity trimming (urgent bins prioritized)
    # -------------------------------------------------
    max_capacity = num_vehicles * VEHICLE_CAPACITY_L
    selected = selected.copy()
    selected["fill_l_today"] = selected["fill_l_today"].clip(lower=0)

    urgent_set = set(urgent_bin_ids or [])
    selected["is_urgent"] = selected["bin_id"].isin(urgent_set)

    # Sort: urgent first, then by fullness (predicted_fill_pct)
    selected = selected.sort_values(
        by=["is_urgent", "predicted_fill_pct"],
        ascending=[False, False],
        ignore_index=True,
    )

    # Keep bins while cumulative demand <= capacity
    cum_demand = selected["fill_l_today"].cumsum()
    capped = selected[cum_demand <= max_capacity].copy()

    # Edge case: if even the first bin exceeds total capacity, keep one anyway
    if capped.empty and not selected.empty:
        capped = selected.head(1).copy()

    if capped.empty:
        if verbose:
            print("After capacity trimming, no bins remain. "
                  "Check vehicle capacity vs. bin demand.")
        return []

    # Detect urgent bins that still couldn't fit after trimming
    missing_urgent = urgent_set - set(capped["bin_id"])
    if verbose and missing_urgent:
        print(
            "WARNING: The following urgent bins could not be included due to "
            f"capacity limits: {sorted(missing_urgent)}"
        )

    # Optionally tell the user how many bins were trimmed out
    if verbose and len(capped) < len(selected):
        trimmed = len(selected) - len(capped)
        print(
            f"Capacity limit: trimmed {trimmed} bins; "
            f"now {len(capped)} bins with total demand "
            f"{capped['fill_l_today'].sum():.0f} L "
            f"(capacity={max_capacity} L)."
        )

    selected = capped
    total_demand = float(selected["fill_l_today"].sum())
    if verbose:
        print(f"Selected {len(selected)} bins after capacity trim, "
              f"total demand ≈ {total_demand:.0f} L")

    # Build depot as the centroid of selected bins
    depot_lat = float(selected["lat"].mean())
    depot_lon = float(selected["lon"].mean())

    depot_row = {
        "bin_id": 0,
        "lat": depot_lat,
        "lon": depot_lon,
        "route_id": -1,
        "service_time_min": 0.0,
        "fill_l_today": 0.0,
        "predicted_fill_pct": 0.0,
        "name": DEPOT_NAME,
    }

    # Ensure selected has a stable index
    selected = selected.copy().reset_index(drop=True)
    selected["name"] = selected.get("name", "")  # ensure column exists

    # Concatenate depot + bins
    nodes = pd.concat([pd.DataFrame([depot_row]), selected], ignore_index=True)

    # Build matrices for all nodes (road-network aware if enabled)
    dist_km, travel_time_min, service_time_min = _build_matrices(nodes)

    # Demand (how many liters picked up at each node)
    n_nodes = len(nodes)
    demand = [0] * n_nodes
    if "fill_l_today" in nodes.columns:
        for i in range(1, n_nodes):  # depot has 0
            demand[i] = int(max(0, round(float(nodes.loc[i, "fill_l_today"]))))

    # OR-Tools index manager and routing model
    manager = pywrapcp.RoutingIndexManager(n_nodes, num_vehicles, 0)
    routing = pywrapcp.RoutingModel(manager)

    # Time callback: travel time + service time at the destination
    def time_callback(from_index, to_index):
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        travel = travel_time_min[from_node][to_node]
        service = service_time_min[to_node]
        return int(travel + service)

    time_callback_index = routing.RegisterTransitCallback(time_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(time_callback_index)

    # Add Time dimension
    routing.AddDimension(
        time_callback_index,
        60,                    # allow up to 60 minutes slack/waiting
        MAX_ROUTE_MIN,
        True,                  # start cumul at zero
        "Time",
    )
    time_dimension = routing.GetDimensionOrDie("Time")

    # Capacity (liters) callback
    def demand_callback(from_index):
        node = manager.IndexToNode(from_index)
        return demand[node]

    demand_callback_index = routing.RegisterUnaryTransitCallback(demand_callback)
    routing.AddDimensionWithVehicleCapacity(
        demand_callback_index,
        0,  # no slack
        [VEHICLE_CAPACITY_L] * num_vehicles,
        True,
        "Capacity",
    )
    capacity_dimension = routing.GetDimensionOrDie("Capacity")

    # Search parameters (slightly more aggressive for better routes)
    search_params = pywrapcp.DefaultRoutingSearchParameters()
    search_params.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PARALLEL_CHEAPEST_INSERTION
    )
    search_params.local_search_metaheuristic = (
        routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    )
    search_params.time_limit.FromSeconds(30)
    search_params.log_search = False

    solution = routing.SolveWithParameters(search_params)
    if solution is None:
        if verbose:
            print("No solution found for current constraints "
                  "(time window or capacity too tight).")
        return []

    routes_out: List[Dict[str, Any]] = []

    if verbose:
        print("\n=== Routes ===")

    for vehicle_id in range(num_vehicles):
        index = routing.Start(vehicle_id)
        route_stops: List[int] = []

        while not routing.IsEnd(index):
            node = manager.IndexToNode(index)
            if node != 0:  # skip depot
                bin_id = int(nodes.loc[node, "bin_id"])
                route_stops.append(bin_id)

            index = solution.Value(routing.NextVar(index))

        # End of route
        end_index = index
        route_time = solution.Value(time_dimension.CumulVar(end_index))
        route_load = solution.Value(capacity_dimension.CumulVar(end_index))

        if verbose:
            if route_stops:
                print(
                    f"Truck {vehicle_id}: {DEPOT_NAME} -> "
                    f"{' -> '.join(str(b) for b in route_stops)} -> {DEPOT_NAME} | "
                    f"time={route_time} min, load={route_load} L"
                )
            else:
                print(f"Truck {vehicle_id}: no assigned bins.")

        if route_stops:
            routes_out.append(
                {
                    "truck_id": vehicle_id,
                    "stops": route_stops,
                    "total_time_min": route_time,
                    "total_load_l": route_load,
                }
            )

    if verbose and not routes_out:
        print("No non-empty routes created (all trucks idle).")

    return routes_out


# ---------------------------------------------------------
# CLI ENTRY POINT
# ---------------------------------------------------------

def _cli():
    print("Smart Waste Route Optimizer")
    print("---------------------------")

    # Number of trucks
    try:
        num_str = input(
            f"Number of trucks to route (default {DEFAULT_NUM_VEHICLES}): "
        ).strip()
    except EOFError:
        num_str = ""
    if num_str.isdigit() and int(num_str) > 0:
        num_vehicles = int(num_str)
    else:
        num_vehicles = DEFAULT_NUM_VEHICLES

    urgent_bin_ids: List[int] = []

    # Optional: filter by service day
    try:
        day = input(
            "Filter by service_day (e.g. Mon, Tue, Thu) or leave blank for all: "
        ).strip()
    except EOFError:
        day = ""
    service_day_filter = day if day else None

    # Optional urgent bins
    try:
        add_urgent = input("Add an urgent bin by ID? [y/N]: ").strip().lower()
    except EOFError:
        add_urgent = "n"

    while add_urgent == "y":
        try:
            bin_id_str = input("  Enter bin ID (numeric, e.g. 42): ").strip()
        except EOFError:
            break

        if not bin_id_str.isdigit():
            print("  Not a valid integer ID.")
        else:
            bin_id_val = int(bin_id_str)
            if bin_id_val not in DF_BINS["bin_id"].values:
                print(f"  Bin ID {bin_id_val} does not exist in data.")
            else:
                urgent_bin_ids.append(bin_id_val)
                print(f"  Added urgent bin ID {bin_id_val}.")

        try:
            add_urgent = input("Add another urgent bin? [y/N]: ").strip().lower()
        except EOFError:
            break

    routes = solve_routes(
        urgent_bin_ids=urgent_bin_ids or None,
        service_day_filter=service_day_filter,
        num_vehicles=num_vehicles,
        verbose=True,
    )

    if routes:
        routes_df = pd.DataFrame(routes)
        print("\n=== Summary ===")
        summary = routes_df[["total_time_min", "total_load_l"]].sum()
        print(summary.to_frame().T)
    else:
        print("\nNo routes generated.")


if __name__ == "__main__":
    _cli()
