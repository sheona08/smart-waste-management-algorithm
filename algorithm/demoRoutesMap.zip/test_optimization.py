import math
import pandas as pd


# ---------- TEST 1: sim_bins3.csv exists ----------
def test_file_exists():
    try:
        pd.read_csv("sim_bins3.csv")
        print("PASS: sim_bins3.csv loaded.")
    except Exception as e:
        print("FAIL: sim_bins3.csv missing or unreadable.", e)


# ---------- TEST 2: Columns exist ----------
def test_columns():
    df = pd.read_csv("sim_bins3.csv")
    required = [
        "bin_id",
        "lat",
        "lon",
        "route_id",
        "service_day",
        "capacity_l",
        "service_time_min",
        "fill_l_today",
        "predicted_fill_pct",
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print("FAIL: Missing columns:", missing)
    else:
        print("PASS: All required columns present.")


# ---------- TEST 3: Optimizer runs end-to-end ----------
def test_optimizer_runs():
    try:
        from optimizeRoutes6 import solve_routes

        routes = solve_routes(verbose=False)
        if routes and any("truck_id" in r for r in routes):
            print("PASS: Optimizer produced routes for at least one truck.")
        else:
            print("FAIL: Optimizer returned no routes.")
    except Exception as e:
        print("FAIL: Optimizer raised an error:", e)


# ---------- TEST 4: Check values are reasonable ----------
def test_values_reasonable():
    df = pd.read_csv("sim_bins3.csv")
    if df["lat"].between(-90, 90).all() and df["lon"].between(-180, 180).all():
        print("PASS: Coordinates are valid.")
    else:
        print("FAIL: Invalid coordinates detected.")


if __name__ == "__main__":
    test_file_exists()
    test_columns()
    test_optimizer_runs()
    test_values_reasonable()

def test_optimal_on_small_toy_instance():
   
    df = pd.read_csv("toy_bins.csv")

    # 2) build a distance matrix that matches what your solver uses
    points = [(0.0, 0.0)]  # depot at index 0
    for _, row in df.iterrows():
        points.append((row["lat"], row["lon"]))

    n = len(points)
    dist = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                dist[i][j] = 0.0
            else:
                dx = points[i][0] - points[j][0]
                dy = points[i][1] - points[j][1]
                dist[i][j] = (dx**2 + dy**2) ** 0.5   # or whatever metric you use

    # 3) solver route
    routes = solve_routes(csv_path="toy_bins.csv", verbose=False)
    # assume for this tiny test you only use 1 truck
    route0 = routes[0]  # {"truck_id": 0, "stops": [...], "time_min": ..., ...}
    # convert to indices: depot (0) -> bin indices -> depot (0)
    idx_route = [0]
    for stop in route0["stops"]:
        idx_route.append(stop["index"])   # or however you store node index
    idx_route.append(0)

    solver_cost = 0
    for i in range(len(idx_route) - 1):
        solver_cost += dist[idx_route[i]][idx_route[i+1]]

    # 4) brute-force best
    bf_cost, bf_route = brute_force_best_route(dist)

    if abs(solver_cost - bf_cost) < 1e-6:
        print("PASS: Solver route cost matches brute-force optimal on toy instance.")
    else:
        print("FAIL: Solver cost", solver_cost, "vs optimal", bf_cost)
        print("  Solver route:", idx_route)
        print("  Optimal route:", bf_route)

import requests

def osrm_can_drive(lat1, lon1, lat2, lon2):
    url = (
        "http://router.project-osrm.org/route/v1/driving/"
        f"{lon1},{lat1};{lon2},{lat2}?overview=false"
    )
    try:
        r = requests.get(url, timeout=3)
        data = r.json()
        return "routes" in data and len(data["routes"]) > 0
    except Exception:
        return False


def test_route_segments_have_road_support(routes, bins_df):
    """
    For each A→B segment in each route, check if OSRM can build
    a real-world driving route. If OSRM fails for ANY segment,
    report it.
    """
    bins_df = bins_df.set_index("bin_id")
    failures = []

    for r in routes:
        stops = r["stops"]
        for a, b in zip(stops[:-1], stops[1:]):
            lat1, lon1 = bins_df.loc[a][["lat", "lon"]]
            lat2, lon2 = bins_df.loc[b][["lat", "lon"]]

            if not osrm_can_drive(lat1, lon1, lat2, lon2):
                failures.append((a, b))

    if failures:
        print("FAIL: Some route segments may cross water / no road:")
        for a, b in failures:
            print(f"  Segment {a} → {b}")
    else:
        print("PASS: All route segments have OSRM-supported road paths.")

import pandas as pd
import requests
from optimizeRoutes7 import solve_routes, DF_BINS


def osrm_can_drive(lat1, lon1, lat2, lon2) -> bool:
    """Return True if OSRM finds a driving route between two points."""
    url = (
        "http://router.project-osrm.org/route/v1/driving/"
        f"{lon1},{lat1};{lon2},{lat2}?overview=false"
    )
    try:
        r = requests.get(url, timeout=5)
        r.raise_for_status()
        data = r.json()
        return "routes" in data and len(data["routes"]) > 0
    except Exception:
        return False


def test_route_segments_use_real_roads(num_trucks: int = 3):
    """Check that every A→B leg in the final routes has a valid OSRM driving path."""
    routes = solve_routes(num_vehicles=num_trucks, verbose=False)
    if not routes:
        print("FAIL: No routes returned.")
        return

    df = DF_BINS.set_index("bin_id")

    bad_segments = []

    for r in routes:
        stops = r["stops"]
        # Check consecutive legs in the route
        for a, b in zip(stops[:-1], stops[1:]):
            if a not in df.index or b not in df.index:
                bad_segments.append((a, b, "missing bin_id in DF_BINS"))
                continue

            lat1, lon1 = df.loc[a, ["lat", "lon"]]
            lat2, lon2 = df.loc[b, ["lat", "lon"]]

            if not osrm_can_drive(lat1, lon1, lat2, lon2):
                bad_segments.append((a, b, "no OSRM route"))

    if bad_segments:
        print("FAIL: Some route legs do not have a valid road path according to OSRM:")
        for a, b, reason in bad_segments:
            print(f"  {a} -> {b}: {reason}")
    else:
        print("PASS: All route legs have valid OSRM driving paths.")


if __name__ == "__main__":
    test_route_segments_use_real_roads(num_trucks=3)
