import pandas as pd

from optimizeRoutes7 import solve_routes
from visualizeRoutes import build_route_map


def main():
    # Load bin data (same file the optimizer uses)
    bins_df = pd.read_csv("sim_bins3.csv")

    # Run the optimizer (no prompts, quiet output)
    routes = solve_routes(
        urgent_bin_ids=None,
        service_day_filter=None,
        verbose=False,
    )

    if not routes:
        print("No routes returned by solver.")
        return

    # Build and save the map
    build_route_map(routes, bins_df, output_html="miami_routes_demo3.html")


if __name__ == "__main__":
    main()
